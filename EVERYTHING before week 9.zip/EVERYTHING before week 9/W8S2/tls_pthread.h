#ifndef __TLS_PTHREAD__
#define __TLS_PTHREAD__

void CRYPTO_thread_setup(void);
void thread_cleanup(void);
#endif
